 
<?php
echo date('H')*60*60+date('i')*60+date('s');
?>
