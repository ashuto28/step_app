//StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)


public class Myclass
{ 
    public static void main(String[] args){
		
     System.out.print("Hello world!!!!");
        

	}
}
