//StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)

#include<stdio.h>
#include<stdlib.h>

int main(){
  
	printf("Ashutosh is Awesome,Excelent,Smart etc guy\nIts the ASHUTOSH, think beyond the limit :D");
  
}