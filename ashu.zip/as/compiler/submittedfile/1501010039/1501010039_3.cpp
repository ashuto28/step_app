//StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)

#include<iostream>
using namespace std;

int main(){
	
cout<<"Ashutosh is Awesome,Excelent,Smart etc guy\nIts the ASHUTOSH, think beyond the limit :D";
	return 0;
  
}
