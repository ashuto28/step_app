#StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)

print("hello world!!!!","ashutosh")
