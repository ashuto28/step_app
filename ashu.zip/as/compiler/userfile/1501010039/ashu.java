import java.io.*;
public class ashu{ 
    public static void main(String[] args)throws IOException {
				
		 	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Enter the string : ");
			String original=in.readLine();
			String reverse="";
			int length=original.length();
			for(int i=length-1;i>=0;i--){
				char ch=original.charAt(i);
				reverse+=ch;
			}
			
			if(original.equalsIgnoreCase(reverse))
				System.out.println("The input "+original+" is palindrom");
			else
				System.out.println("The input "+original+" is not palindrom");
     }
}
