#StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)


print ("Welcome to StepApp coding arena!!")
