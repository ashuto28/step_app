//StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)

#include<stdio.h>
#include<stdlib.h>

int main(){

	printf("Wellcome to StepApp coding arena\n");
	return 0;
  
}
