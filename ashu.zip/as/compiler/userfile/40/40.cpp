//StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)

#include<iostream>
using namespace std;

int main(){
	
	cout<<"Hello world!!!!";
	return 0;
  
}
