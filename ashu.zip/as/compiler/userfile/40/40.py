#StepApp coding arena designed and developed by Ashutosh Dwivedi (UCER)


print ("Hello world!!!!",end='')
